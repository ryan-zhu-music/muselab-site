//===================================================//
//Tuplet information for MuseLab
//forked from XiaoMigros/Beam_Over_Rests
//v 1.0
//changelog:
//===================================================//

function getInfo(e, tick) {
	if (e.tuplet) {
		var c = curScore.newCursor()
		c.rewind(Cursor.SCORE_START)
		var tupletStart;
		while (c.next()) {
			if (c.element.tuplet) {
				for (var i in c.element.tuplet.elements) {
					if (c.element.tuplet.elements[i] == e) {
						tupletStart = c.tick
					}	
					break;
				}
			}
			c.next()
		}
		var tupletTracker = []
		
		var tupletDuration = 0;
		var tupletLength = duration(e.tuplet)*division*4.0;
		//tupletLength: absolute; tupletDuration: relative to inside tuplet
		var tupletEnd = tupletStart + tupletLength;
		var tupletN = e.tuplet.actualNotes;
		var tupletD = e.tuplet.normalNotes;
		
		c.rewindToTick(tupletStart)
		
		while (c.element && c.tick < tupletEnd) {
			//walks through tuplet and logs all the relative note lengths
			tupletTracker.push(duration(c.element));
			c.next();
		}
		for (var i in tupletTracker) {
			tupletDuration += tupletTracker[i]
			//adds all the note lengths together to form the relative length of the tuplet
		}
		var tupletBaseLength = tupletDuration / tupletN
		//modified beaming functions for tuplet, using tuplet divisioned tick values
		
		//var tupletBaseLengthActual = tupletDuration*1920 / tupletLength
		var tupletBaseLengthActual = tupletDuration*division*4.0;
		//actual value of one base unit in ticks
		
		debugLog(tupletN + "/" + tupletD + " tuplet\n" + 
		"external duration: " + tupletLength  + ", internal duration: " + tupletDuration + " (Base Length: " + tupletBaseLength +
		", actual: " + tupletBaseLengthActual + ")" + "\nstarts at: " + tupletStart + ", ends at: " + tupletEnd)
		
		return ([tupletStart, fraction(e.tuplet.actualNotes, tupletBaseLength), e.tuplet.duration])
	} else {return [false, false, false];}//its funny like this
}

function duration(e) {
	if e.duration {return e.duration.numerator / e.duration.denominator}
	else {return false}
}
